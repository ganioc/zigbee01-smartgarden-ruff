'use strict';

var driver = require('ruff-driver');
//var ReadStreaming = require('./read-streaming');

var buffer = new Buffer(256);
var index = 0;

module.exports = driver({

    attach: function (inputs, context) {
        // this._<interface> = inputs['<interface>'];
	console.log('uart0 attached');
	var that = this;

	this._uart = inputs['uart'];

	//var readStreaming = new ReadStreaming(this._uart);

	this._uart.on('data', function(data){
	    console.log('uart0 on raw data:' + data.length);
	    //console.log(data);
	    that.emit('data',data);
	});
	
	// readStreaming.on('data', function(data){
	//     console.log('uart0 on raw data:' + data.length);
	//     //console.log();
	//     that.emit('data',data);
	// });

	// readStreaming.start();
	
    },

    exports: {
        write: function (data, callback) {
            // this._<interface>.<method>
	    console.log("Uart0 RAW write:" + data.length);
	    //console.log(data);
	    console.log(typeof data);
	    this._uart.write(data, callback);
        }
    }

});
